module.exports = require('./lib/fizz-buzz-convert.js');
